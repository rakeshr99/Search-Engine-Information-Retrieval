EXECUTION
1. Unzip the folder
2. The folder contains nbtrain.py and nbtest.py python file which is the source code
3. Using command line Type nbtrain.py <TRAININGDIRECTORY> 
3. Using command line Type nbtest.py <TRAININGDIRECTORY> <DEVELOPMENTDATADIRECTORY> <TESTDIRECTORY>  <RESULTDIRECTORY>. 
4. The output files will be placed in the result directories for all the tasks

TASK2-PREDICTION
Percentage of positive and negative reviews in the development data that were classified correctly is 80.0% 

LIBRARIES USED
collections
os
sys
math


REFERENCES AND CITATION

http://www.ccs.neu.edu/home/rplatt/cs5100_spring2017/pa0/hw_asst0.html
http://docs.python-requests.org/en/master/
http://docs.python-requests.org/en/master/user/quickstart/
http://beautiful-soup-4.readthedocs.io/en/latest/#css-selectors
https://learnpythonthehardway.org/
https://docs.python.org/2/library/os.path.html
https://docs.python.org/3/tutorial/datastructures.html
http://stackoverflow.com/
https://www.youtube.com/watch?v=HBxCHonP6Ro&list=PL6gx4Cwl9DGAcbMi1sH6oAMk4JHw91mC_ 