
import os
import sys
import math
from collections import Counter

input_arguments = sys.argv[:]
directorypath = input_arguments[1]
devdirectorypath = input_arguments[2]
testdirectorypath=input_arguments[3]
resultpath= input_arguments[4]

# directory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\\train")
# devdirectory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\dev")
# testdirectory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\\test")

directory = os.path.normpath(directorypath)
devdirectory = os.path.normpath(devdirectorypath)
testdirectory = os.path.normpath(testdirectorypath)
# directory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\test")
vocabularydict= {}
priorprob = {}
negworddict={}
posworddict={}
negwordtotal=0
poswordtotal=0
vocabsize=0
def vocabulary():
    global poswordtotal,negwordtotal,vocabsize,posworddict,negworddict,priorprob,vocabularydict
    for subdir, dirs, files in os.walk(directory):
        for file in files:
            f = open(os.path.join(subdir, file), 'r')
            # dir = subdir.split('\\')[7]
            if 'neg' in subdir:
                dir = 'neg'
            else:
                dir = 'pos'
            # print os.path.join(subdir, file)
            docid = file.split(".txt")[0]
            # print docid
            filedict = Counter(f.read().split())
            # print filedict
            for key, value in filedict.items():
                if key in vocabularydict:
                    vocabularydict[key][docid] = str(value)
                else:
                    vocabularydict[key] = {docid: str(value)}

            for key, value in filedict.items():
                if dir == 'neg':
                    if key in negworddict:
                        negworddict[key] = negworddict[key] + value
                    else:
                        negworddict[key] = value
                else:
                    if key in posworddict:
                        posworddict[key] = posworddict[key] + value
                    else:
                        posworddict[key] = value


        # print negworddict
            # print sorted(frequniinverteddict.items(), key=lambda kv: kv[1], reverse=True)
    wordremovelist=[]
    frequniinverteddict = dict.fromkeys(vocabularydict.keys(), 0)
    for key, value in vocabularydict.items():
        for key1, value1 in value.items():
            frequniinverteddict[key] = frequniinverteddict[key] + int(value1)
    for key, value in frequniinverteddict.items():
        if value < 5:
            del vocabularydict[key]
            wordremovelist.append(key)
    # entireVocabulary = {k: v for k, v in entireVocabulary.iteritems() if v >= 5}
    for key in wordremovelist:
        if key in negworddict:
            del negworddict[key]
        if key in posworddict:
            del posworddict[key]
    frequniinverteddict = {}
    # frequniinverteddict = dict.fromkeys(posworddict.keys(), 0)
    # for key, value in posworddict.items():
    #         frequniinverteddict[key] = frequniinverteddict[key] + int(value)
    # for key, value in frequniinverteddict.items():
    #     if value < 5:
    #         del posworddict[key]
    # frequniinverteddict = {}
    # frequniinverteddict = dict.fromkeys(negworddict.keys(), 0)
    # for key, value in negworddict.items():
    #         frequniinverteddict[key] = frequniinverteddict[key] + int(value)
    # for key, value in frequniinverteddict.items():
    #     if value < 5:
    #         del negworddict[key]
    vocabsize = len(negworddict.keys())
    print vocabsize
    vocabsize = len(posworddict.keys())
    print vocabsize
    vocabsize = len(vocabularydict.keys())
    print vocabsize
    poswordtotal = sum(posworddict.values())
    negwordtotal = sum(negworddict.values())
    print len(posworddict.keys())
    print len(negworddict.keys())
    print poswordtotal
    print negwordtotal
    # keys_a = set(posworddict.keys())
    # keys_b = set(negworddict.keys())
    # intersection = keys_a & keys_b
    # vocabsize = (len(posworddict.keys()) + len(negworddict.keys()) - len(intersection))
    # return vocabularydict

def priorprobability():
    numberoffiles={}
    for subdir, dirs, files in os.walk(directory):
        for dir in dirs:
            if dir == 'neg':
                numberoffiles[dir] = len(os.listdir(os.path.join(subdir, dir)))
            else:
                numberoffiles[dir] = len(os.listdir(os.path.join(subdir, dir)))

    for key,value in numberoffiles.items():
        priorprob[key]= (value/(float)(sum(numberoffiles.values())))
    # return priorprob
def classify():
    global poswordtotal, negwordtotal, vocabsize, posworddict, negworddict, priorprob, vocabularydict
    vocabulary()
    priorprobability()
    posscore=0
    negscore=0
    posdirscore=0
    negdirscore = 0
    # resultfile = os.path.join("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\Result",
    #                           "Classifieddata" + ".txt")
    resultfile = os.path.join(resultpath,"Classifieddata" + ".txt")
    file1 = open(resultfile, "a")
    file1.write("DEVELOPMENT DATA\n\n")
    file1.write("File : NegativeScore : PositiveScore : Class\n\n")
    for subdir, dirs, files in os.walk(devdirectory):
        for file in files:
            probofneg=0
            probofpos=0
            productofwordspos=1
            productofwordsneg=1
            dir = subdir.split('\\')[7]
            if dir == 'neg':
                negdirscore= negdirscore +1
            else:
                posdirscore = posdirscore +1
            f = open(os.path.join(subdir, file), 'r')
            wordlist = f.read().split()
            for word in wordlist:
                proboflikelihoodneg = 0
                proboflikelihoodpos = 0
                if word in posworddict:
                    proboflikelihoodpos = ((1 + posworddict[word])/(float)(vocabsize + poswordtotal))
                else:
                    proboflikelihoodpos = (1/(float)(vocabsize))
                productofwordspos = productofwordspos + math.log(proboflikelihoodpos)
                if word in negworddict:
                    proboflikelihoodneg = ((1 + negworddict[word])/(float)(vocabsize + negwordtotal))
                else:
                    proboflikelihoodneg = (1/(float)(vocabsize))
                productofwordsneg = productofwordsneg + math.log(proboflikelihoodneg)
            probofneg= productofwordsneg + math.log(priorprob['neg'])
            probofpos = productofwordspos + math.log(priorprob['pos'])

            if probofneg>probofpos:
                file1.write(file + " : "+str(probofneg) + " : "+ str(probofpos) +" : " + "NEGATIVE REVIEW\n")
                if dir == 'neg':
                    negscore = negscore + 1
            else:
                file1.write(file + " : "+str(probofneg) + " : "+ str(probofpos) +" : "  + "POSITIVE REVIEW\n")
                if dir == 'pos':
                    posscore = posscore + 1
    accuracy= (((negscore/(float)(negdirscore)) + (posscore/(float)(posdirscore)))/((float)(2)))
    print str(negdirscore) + "  " +str(posdirscore) + "  " + str(negscore) + "  " +str(posscore)
    file1.write("Perccentage Accuracy : "+ str(accuracy*100)+"%")


def testclassify():
    global poswordtotal, negwordtotal, vocabsize, posworddict, negworddict, priorprob, vocabularydict
    # vocabulary()
    # priorprobability()
    posscore=0
    negscore=0
    posdirscore=0
    negdirscore = 0
    wordposweight={}
    wordnegweight={}
    wordposweightratio = {}
    wordnegweightratio = {}
    # resultfile = os.path.join("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\Result",
    #                           "ClassifiedTestdata" + ".txt")
    resultfile = os.path.join(resultpath, "ClassifiedTestdata" + ".txt")
    file1 = open(resultfile, "a")
    file1.write("TEST DATA\n\n")
    file1.write("File : NegativeScore : PositiveScore : Class\n\n")
    for subdir, dirs, files in os.walk(testdirectory):
        for file in files:
            probofneg=0
            probofpos=0
            productofwordspos=1
            productofwordsneg=1
            # dir = subdir.split('\\')[7]
            # if dir == 'neg':
            #     negdirscore= negdirscore +1
            # else:
            #     posdirscore = posdirscore +1
            f = open(os.path.join(subdir, file), 'r')
            wordlist = f.read().split()
            for word in wordlist:
                proboflikelihoodneg = 0
                proboflikelihoodpos = 0
                if word in posworddict:
                    proboflikelihoodpos = ((1 + posworddict[word])/(float)(vocabsize + poswordtotal))
                else:
                    proboflikelihoodpos = (1/(float)(vocabsize))
                productofwordspos = productofwordspos + math.log(proboflikelihoodpos)
                if word in negworddict:
                    proboflikelihoodneg = ((1 + negworddict[word])/(float)(vocabsize + negwordtotal))
                else:
                    proboflikelihoodneg = (1/(float)(vocabsize))
                productofwordsneg = productofwordsneg + math.log(proboflikelihoodneg)

                if word in wordnegweight:
                    wordnegweight[word] = wordnegweight[word] + proboflikelihoodneg
                else:
                    wordnegweight[word] = proboflikelihoodneg
                if word in wordposweight:
                    wordposweight[word] = wordposweight[word] + proboflikelihoodpos
                else:
                    wordposweight[word] = proboflikelihoodpos
            probofneg= productofwordsneg + math.log(priorprob['neg'])
            probofpos = productofwordspos + math.log(priorprob['pos'])

            if probofneg>probofpos:
                file1.write(file + " : "+str(probofneg) + " : "+ str(probofpos) +" : " + "NEGATIVE REVIEW\n")
                # if dir == 'neg':
                #     negscore = negscore + 1
            else:
                file1.write(file + " : "+str(probofneg) + " : "+ str(probofpos) +" : "  + "POSITIVE REVIEW\n")
                # if dir == 'pos':
                #     posscore = posscore + 1
    # accuracy= (((negscore/(float)(negdirscore)) + (posscore/(float)(posdirscore)))/((float)(2)))
    # print str(negdirscore) + "  " +str(posdirscore) + "  " + str(negscore) + "  " +str(posscore)
    # file1.write("Perccentage Accuracy : "+ str(accuracy*100)+"%")
    for key,value in wordposweight.items():
        wordposweightratio[key]= math.log((value/(float)(wordnegweight[key])))
    for key,value in wordnegweight.items():
        wordnegweightratio[key]= math.log((value/(float)(wordposweight[key])))
    wordposweightratio = sorted(wordposweightratio.items(), key=lambda kv: kv[1], reverse=True)
    wordnegweightratio = sorted(wordnegweightratio.items(), key=lambda kv: kv[1], reverse=True)
    wordposweightratio = wordposweightratio[0:20]
    wordnegweightratio = wordnegweightratio[0:20]
    # completeName = os.path.join("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\Result",
    #                             "20postonegweight" + ".txt")
    completeName = os.path.join(resultpath, "20postonegweight" + ".txt")
    file1 = open(completeName, "w")
    file1.write("LIST OF 20 TERMS WITH HIGHEST RATIO OF POSITIVE TO NEGATIVE WEIGHT\n\n")
    number=1
    for key in wordposweightratio:
        file1.write(str(number) + "  " + str(key) + "\n")
        number = number + 1
    file1.close()
    # completeName = os.path.join("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\Result",
    #                             "20negtoposweight" + ".txt")
    completeName = os.path.join(resultpath, "20negtoposweight" + ".txt")
    file1 = open(completeName, "w")
    file1.write("LIST OF 20 TERMS WITH HIGHEST RATIO OF NEGATIVE TO POSITIVE WEIGHT\n\n")
    number = 1
    for key in wordnegweightratio:
        file1.write(str(number) + "  " + str(key) + "\n")
        number = number + 1
    file1.close()
# vocabulclassify()ary()
classify()
testclassify()