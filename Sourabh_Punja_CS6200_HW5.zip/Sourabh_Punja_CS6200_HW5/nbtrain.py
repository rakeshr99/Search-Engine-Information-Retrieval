
import os
import sys
import math
from collections import Counter

input_arguments = sys.argv[:]
directorypath = input_arguments[1]
# devdirectorypath = input_arguments[2]
# testdirectorypath=input_arguments[3]
# resultpath= input_arguments[4]

# directory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\\train")
# devdirectory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\dev")
# testdirectory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\textcat\\test")

directory = os.path.normpath(directorypath)
# devdirectory = os.path.normpath(devdirectorypath)
# testdirectory = os.path.normpath(testdirectorypath)
# directory = os.path.normpath("C:\Users\Sourabh Punja\PycharmProjects\HW5\\test")
vocabularydict= {}
priorprob = {}
negworddict={}
posworddict={}
negwordtotal=0
poswordtotal=0
vocabsize=0
def vocabulary():
    global poswordtotal,negwordtotal,vocabsize,posworddict,negworddict,priorprob,vocabularydict
    for subdir, dirs, files in os.walk(directory):
        for file in files:
            f = open(os.path.join(subdir, file), 'r')
            # dir = subdir.split('\\')[7]
            if 'neg' in subdir:
                dir = 'neg'
            else:
                dir = 'pos'
            # print os.path.join(subdir, file)
            docid = file.split(".txt")[0]
            # print docid
            filedict = Counter(f.read().split())
            # print filedict
            for key, value in filedict.items():
                if key in vocabularydict:
                    vocabularydict[key][docid] = str(value)
                else:
                    vocabularydict[key] = {docid: str(value)}

            for key, value in filedict.items():
                if dir == 'neg':
                    if key in negworddict:
                        negworddict[key] = negworddict[key] + value
                    else:
                        negworddict[key] = value
                else:
                    if key in posworddict:
                        posworddict[key] = posworddict[key] + value
                    else:
                        posworddict[key] = value


        # print negworddict
            # print sorted(frequniinverteddict.items(), key=lambda kv: kv[1], reverse=True)
    wordremovelist=[]
    frequniinverteddict = dict.fromkeys(vocabularydict.keys(), 0)
    for key, value in vocabularydict.items():
        for key1, value1 in value.items():
            frequniinverteddict[key] = frequniinverteddict[key] + int(value1)
    for key, value in frequniinverteddict.items():
        if value < 5:
            del vocabularydict[key]
            wordremovelist.append(key)
    # entireVocabulary = {k: v for k, v in entireVocabulary.iteritems() if v >= 5}
    for key in wordremovelist:
        if key in negworddict:
            negworddict[key]
        if key in posworddict:
            del posworddict[key]
    frequniinverteddict = {}
    # frequniinverteddict = dict.fromkeys(posworddict.keys(), 0)
    # for key, value in posworddict.items():
    #         frequniinverteddict[key] = frequniinverteddict[key] + int(value)
    # for key, value in frequniinverteddict.items():
    #     if value < 5:
    #         del posworddict[key]
    # frequniinverteddict = {}
    # frequniinverteddict = dict.fromkeys(negworddict.keys(), 0)
    # for key, value in negworddict.items():
    #         frequniinverteddict[key] = frequniinverteddict[key] + int(value)
    # for key, value in frequniinverteddict.items():
    #     if value < 5:
    #         del negworddict[key]
    vocabsize = len(negworddict.keys())
    print vocabsize
    vocabsize = len(posworddict.keys())
    print vocabsize
    vocabsize = len(vocabularydict.keys())
    print vocabsize
    poswordtotal = sum(posworddict.values())
    negwordtotal = sum(negworddict.values())
    print len(posworddict.keys())
    print len(negworddict.keys())
    print poswordtotal
    print negwordtotal
    # keys_a = set(posworddict.keys())
    # keys_b = set(negworddict.keys())
    # intersection = keys_a & keys_b
    # vocabsize = (len(posworddict.keys()) + len(negworddict.keys()) - len(intersection))
    # return vocabularydict

def priorprobability():
    numberoffiles={}
    for subdir, dirs, files in os.walk(directory):
        for dir in dirs:
            if dir == 'neg':
                numberoffiles[dir] = len(os.listdir(os.path.join(subdir, dir)))
            else:
                numberoffiles[dir] = len(os.listdir(os.path.join(subdir, dir)))

    for key,value in numberoffiles.items():
        priorprob[key]= (value/(float)(sum(numberoffiles.values())))
    # return priorprob


vocabulary()
priorprobability()